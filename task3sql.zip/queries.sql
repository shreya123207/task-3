1. View first 10 rows
SELECT * FROM cleandata LIMIT 10;

 2. Total number of transactions (rows)
SELECT COUNT(*) AS TotalTransactions FROM cleandata;

 3. Top 5 most sold products
SELECT Description, SUM(Quantity) AS TotalSold
FROM cleandata
GROUP BY Description
ORDER BY TotalSold DESC
LIMIT 5;

4. Total revenue
SELECT SUM(Quantity * UnitPrice) AS TotalRevenue
FROM cleandata;

 5. Revenue by country
SELECT Country, SUM(Quantity * UnitPrice) AS Revenue
FROM cleandata
GROUP BY Country
ORDER BY Revenue DESC;

 6. Average order value per customer
SELECT CustomerID, AVG(Quantity * UnitPrice) AS AvgOrderValue
FROM cleandata
GROUP BY CustomerID
ORDER BY AvgOrderValue DESC
LIMIT 10;

 7. Number of unique customers
SELECT COUNT(DISTINCT CustomerID) AS UniqueCustomers FROM cleandata;